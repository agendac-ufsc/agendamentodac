# Design Brainstorming – Termo de Autorização DAC 2026

<response>
<text>
**Design Movement:** Institutional Modernism — clean, authoritative, government-document aesthetic
**Core Principles:**
1. Fidelidade ao documento original: layout e tipografia que remetem a formulários oficiais
2. Clareza hierárquica: seções bem demarcadas com numeração romana e títulos em negrito
3. Fundo branco com cartões levemente sombreados para cada seção
4. Formulário centrado com largura máxima de 800px, como um documento impresso

**Color Philosophy:** Azul institucional (#1a56db) para títulos e botão primário; cinza neutro para bordas e labels; fundo off-white (#f8f9fa) para a página.

**Layout Paradigm:** Documento vertical único, seções empilhadas com cartões brancos, sem sidebar. Campos em grid 2 colunas onde cabem.

**Signature Elements:**
- Ícone de documento 📄 no cabeçalho
- Divisores horizontais entre seções
- Acordeão para cláusulas com chevron

**Interaction Philosophy:** Validação ao tentar submeter; campos obrigatórios marcados com asterisco; feedback visual de erro com borda vermelha.

**Animation:** Transição suave (300ms ease) para abertura/fechamento das cláusulas. Sem animações excessivas.

**Typography System:** Fonte principal: Source Serif 4 para títulos (serifa institucional); Inter para campos e textos de corpo.
</text>
<probability>0.08</probability>
</response>

<response>
<text>
**Design Movement:** Neo-Brutalism Documental — formulário com estética de papel físico digitalizado
**Core Principles:**
1. Bordas sólidas pretas, sem sombras suaves
2. Tipografia monoespaçada para campos de entrada
3. Fundo amarelado (#fffde7) simulando papel envelhecido
4. Seções com cabeçalhos em caixa alta e sublinhado duplo

**Color Philosophy:** Preto e amarelo-papel; azul apenas para o botão de ação principal.

**Layout Paradigm:** Coluna única estreita (max 700px), campos com label acima e borda inferior apenas (underline style).

**Signature Elements:**
- Linha pontilhada separando seções
- Campos de assinatura com linha tracejada
- Numeração de cláusulas em romano grande

**Interaction Philosophy:** Minimalista; sem animações; foco em legibilidade e preenchimento rápido.

**Animation:** Nenhuma.

**Typography System:** IBM Plex Mono para campos; Playfair Display para títulos de seção.
</text>
<probability>0.05</probability>
</response>

<response>
<text>
**Design Movement:** Clean Institutional — fiel ao original, moderno e acessível
**Core Principles:**
1. Reprodução fiel do layout do formulário original
2. Fundo cinza-claro (#f3f4f6) para a página, cartões brancos para cada seção
3. Tipografia legível com hierarquia clara (títulos de seção, labels, placeholders)
4. Botão "Gerar PDF" azul proeminente

**Color Philosophy:** Azul (#2563eb) como cor primária institucional; cinza (#6b7280) para textos secundários; vermelho (#ef4444) para erros.

**Layout Paradigm:** Coluna central (max-w-3xl), seções empilhadas em cartões com padding generoso.

**Signature Elements:**
- Ícone de documento no título
- Checkboxes customizados para seleção de espaço
- Acordeão para cláusulas

**Interaction Philosophy:** Validação visual, feedback de erro, checkbox de aceite antes de gerar PDF.

**Animation:** Suave abertura de acordeão (200ms).

**Typography System:** System font stack para máxima legibilidade; títulos em font-semibold.
</text>
<probability>0.07</probability>
</response>

## Chosen Approach
**Clean Institutional** — reprodução fiel ao original com fundo cinza-claro, cartões brancos por seção, azul institucional como cor primária, e tipografia clara com hierarquia bem definida.

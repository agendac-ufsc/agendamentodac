/*
 * Design: Clean Institutional
 * - Background: gray-100 page, white cards per section
 * - Primary color: blue-600 (#2563eb) — institutional
 * - Typography: system font, semibold titles, clear hierarchy
 * - Layout: centered single column (max-w-3xl), stacked cards
 * - Interactions: accordion for clauses, custom checkboxes, PDF generation
 * 
 * Key Features:
 * - Section II includes narrative text with data fields embedded
 * - Date/time fields are free text (not HTML date/time inputs)
 * - Signature area has ample space for electronic signatures
 * - PDF generation matches original document structure
 */

import { useState, useEffect } from "react";
import { FileText, ChevronDown, ChevronUp, Download, Trash2, Settings } from "lucide-react";
import { toast } from "sonner";
import { jsPDF } from "jspdf";
import { useLocation } from "wouter";

interface AdminSettings {
  editalTitle: string;
  responsavelNome: string;
  cpfAutorizadora: string;
}

interface FormData {
  espacoTeatro: boolean;
  espacoIgreja: boolean;
  nomeEvento: string;
  dataHorarioEvento: string;
  outrasInformacoes: string;
  nomeCompleto: string;
  cpfCnpj: string;
  rg: string;
  telefone: string;
  endereco: string;
  numero: string;
  apartamento: string;
  bairro: string;
  cidade: string;
  aceitaTermos: boolean;
}

const initialForm: FormData = {
  espacoTeatro: false,
  espacoIgreja: false,
  nomeEvento: "",
  dataHorarioEvento: "",
  outrasInformacoes: "",
  nomeCompleto: "",
  cpfCnpj: "",
  rg: "",
  telefone: "",
  endereco: "",
  numero: "",
  apartamento: "",
  bairro: "",
  cidade: "",
  aceitaTermos: false,
};

const clausulas = [
  {
    titulo: "Cláusula Primeira - Do Objeto e do Prazo da Autorização",
    conteudo: [
      "O objeto deste termo é a autorização de uso de dependências específicas de espaço cultural da AUTORIZADORA pelo(a) AUTORIZADO(A) para fim exclusivo de realização de evento, na forma especificada no preâmbulo acima, observado o calendário prioritário previamente estipulado pela Universidade Federal de Santa Catarina, por meio de Edital Público.",
      "Excluem-se expressamente da autorização ora ajustada quaisquer outras áreas e/ou dependências que não a referida no preâmbulo desta autorização.",
    ],
  },
  {
    titulo: "Cláusula Segunda - Da Taxa de Utilização",
    conteudo: [
      "Nos casos de locação do espaço para eventos particulares e/ou não gratuitos, a AUTORIZADORA cobrará as taxas referentes à utilização do espaço cultural objeto desta autorização, conforme valores definidos em Portaria editada pela Secretaria de Cultura, nos termos da legislação vigente à época da autorização.",
      "Havendo cancelamento de apresentação do evento objeto deste termo, por qualquer motivo que seja, a taxa de locação paga pelo(a) AUTORIZADO(A) à AUTORIZADORA não será devolvida, podendo o (a) AUTORIZADO(A) reagendar a data para outra disponível no calendário anexo ao Edital vigente.",
    ],
  },
  {
    titulo: "Cláusula Terceira - Dos Ingressos e dos Valores Fixados",
    conteudo: [
      "A comercialização dos ingressos do espetáculo é de total responsabilidade do AUTORIZADO(A), inclusive no que tange às regras de comercialização total ou meia entrada.",
    ],
  },
  {
    titulo: "Cláusula Quarta - Das Obrigações e dos Direitos da AUTORIZADORA",
    conteudo: [
      "A AUTORIZADORA, além de outras condições previstas em normas específicas, compromete-se a:",
      "a) autorizar o uso das dependências e equipamentos do espaço cultural objeto deste termo o(a) AUTORIZADO(A), o qual será liberado para montagem no(s) dia(s) do(s) evento(s), a partir das (8) oito horas;",
      "b) autorizar os serviços da sua equipe técnica, nos termos e nos horários previamente acordados com a administração do espaço cultural objeto deste termo;",
      "c) disponibilizar, dentro das condições previstas para o bom funcionamento do palco e suas instalações, os equipamentos de sonorização, iluminação e vídeo existentes e instalados no espaço cultural objeto deste termo, não compreendendo o transporte, o carregamento e o descarregamento de equipamentos e materiais do(a) AUTORIZADO(A);",
      "d) promover a ordem e a guarda do espaço cultural objeto deste termo, não se responsabilizando por objetos de uso pessoal, material cênico e equipamentos do(a) AUTORIZADO(A) e de sua equipe.",
    ],
  },
  {
    titulo: "Cláusula Quinta - Das Obrigações e dos Direitos do(a) AUTORIZADO(A)",
    conteudo: [
      "O(A) AUTORIZADO(A) além de outras condições previstas em normas específicas, compromete-se a:",
      "a) realizar o evento descrito no preâmbulo desta autorização, utilizando as instalações do espaço cultural exclusivamente para os fins especificados;",
      "b) restituir as instalações do espaço cultural à AUTORIZADORA nas mesmas condições físicas, técnicas e de limpeza em que foram recebidas;",
      "c) indenizar a AUTORIZADORA pelos danos materiais e/ou morais porventura causados contra a mesma, por si ou por seus prepostos;",
      "d) responsabilizar-se por quaisquer danos materiais e/ou pessoais que sejam causados contra terceiros nas instalações do espaço cultural objeto deste termo quer sejam causados por si ou por seus prepostos;",
      "e) cumprir as exigências legais da SBAT (Sociedade Brasileira Autores Teatrais) ECAD (Escritório Central de Arrecadação de Direitos Autorais de Música Tocada) SATED (Sindicato dos Artistas e Técnicos em Espetáculos de Diversões) Ordem dos Músicos do Brasil Juizado da Infância e Juventude e similares, apresentando as respectivas comprovações à AUTORIZADORA, no mínimo 48 (quarenta e oito) horas antes da primeira utilização do espaço cultural;",
      "f) expirado o prazo ajustado para a utilização do espaço cultural objeto deste termo, retirar do mesmo todo o material de sua propriedade imediatamente após a última apresentação do espetáculo e restituir a área no máximo em até 04 (quatro) horas completamente desocupado, nas mesmas condições em que recebeu. A não retirada de todo o material, no referido prazo, sujeitará o(a) AUTORIZADO(A) ao pagamento de multa correspondente a 10% (dez por cento) do valor de uma diária da taxa de ocupação do espaço cultural objeto deste termo, para o evento equivalente, bem como exime a AUTORIZADORA de quaisquer responsabilidades ou danos que possam ocorrer ao material daquela;",
      "g) entregar e instalar cenários e equipamentos somente no(s) horário(s) previamente acordado(s) com a administração do espaço cultural;",
      "h) observar a expressa proibição de veiculação de publicidade enganosa, em benefício próprio, acerca do objeto a que se refere este termo;",
      "i) arcar com eventuais taxas, multas e outras sanções decorrentes da colocação de cartazes e propagandas, em geral expostas em locais públicos sem a devida autorização;",
      "j) observar que a entrada do público ao espaço cultural se dará obrigatoriamente no mínimo até 00:30 (trinta) minutos antes do início do espetáculo. Fica executada desta medida aquele espetáculo que dele faz parte a entrada do público.",
    ],
  },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const [form, setForm] = useState<FormData>(initialForm);
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const [openClausulas, setOpenClausulas] = useState<boolean[]>(clausulas.map(() => false));
  const [clausulasAutorizadas, setClausulasAutorizadas] = useState<boolean[]>(clausulas.map(() => false));
  const [adminSettings, setAdminSettings] = useState<AdminSettings>({
    editalTitle: "Este documento é parte integrante do Edital Mais Arte - N° 002/2026/DAC/SeCArtE",
    responsavelNome: "Andréa Búrigo Ventura",
    cpfAutorizadora: "",
  });

  useEffect(() => {
    // First, check URL parameters
    const params = new URLSearchParams(window.location.search);
    const urlEdital = params.get("edital");
    const urlResponsavel = params.get("responsavel");
    const urlCpf = params.get("cpf");

    // Then check localStorage
    const saved = localStorage.getItem("adminSettings");
    const savedSettings = saved ? JSON.parse(saved) : null;

    // Merge: URL params override localStorage, localStorage overrides defaults
    setAdminSettings({
      editalTitle: urlEdital || savedSettings?.editalTitle || "Este documento é parte integrante do Edital Mais Arte - N° 002/2026/DAC/SeCArtE",
      responsavelNome: urlResponsavel || savedSettings?.responsavelNome || "Andréa Búrigo Ventura",
      cpfAutorizadora: urlCpf || savedSettings?.cpfAutorizadora || "",
    });
  }, []);

  function handleChange(field: keyof FormData, value: string | boolean) {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  }

  function toggleClausula(index: number) {
    setOpenClausulas((prev) => prev.map((v, i) => (i === index ? !v : v)));
  }

  function toggleClausulaAutorizacao(index: number) {
    setClausulasAutorizadas((prev) => prev.map((v, i) => (i === index ? !v : v)));
  }

  function isClausulaEnabled(index: number): boolean {
    if (index === 0) return true;
    return clausulasAutorizadas[index - 1];
  }

  function allClausulasAutorizadas(): boolean {
    return clausulasAutorizadas.every((auth) => auth === true);
  }

  function validate(): boolean {
    const newErrors: Partial<Record<keyof FormData, string>> = {};
    if (!form.espacoTeatro && !form.espacoIgreja) {
      newErrors.espacoTeatro = "Selecione ao menos um espaço.";
    }
    if (!form.nomeEvento.trim()) newErrors.nomeEvento = "Campo obrigatório.";
    if (!form.dataHorarioEvento.trim()) newErrors.dataHorarioEvento = "Campo obrigatório.";
    if (!form.nomeCompleto.trim()) newErrors.nomeCompleto = "Campo obrigatório.";
    if (!form.cpfCnpj.trim()) newErrors.cpfCnpj = "Campo obrigatório.";
    if (!form.rg.trim()) newErrors.rg = "Campo obrigatório.";
    if (!form.telefone.trim()) newErrors.telefone = "Campo obrigatório.";
    if (!form.endereco.trim()) newErrors.endereco = "Campo obrigatório.";
    if (!form.numero.trim()) newErrors.numero = "Campo obrigatório.";
    if (!form.bairro.trim()) newErrors.bairro = "Campo obrigatório.";
    if (!form.cidade.trim()) newErrors.cidade = "Campo obrigatório.";
    if (!form.aceitaTermos) newErrors.aceitaTermos = "Você deve aceitar os termos.";
    if (!allClausulasAutorizadas()) newErrors.aceitaTermos = "Você deve autorizar todas as cláusulas.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function gerarPDF() {
    if (!validate()) {
      toast.error("Por favor, preencha todos os campos obrigatórios.");
      return;
    }

    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const pageW = 210;
    const margin = 15;
    const contentW = pageW - 2 * margin;
    const centerX = pageW / 2;
    let y = 15;

    const checkPageBreak = (currentY: number, neededSpace: number) => {
      if (currentY + neededSpace > 277) {
        doc.addPage();
        return 15;
      }
      return currentY;
    };

    const renderMixedText = (parts: Array<{ text: string; bold: boolean }>, startY: number, maxWidth: number) => {
      let currentY = startY;
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");

      let currentLine: Array<{ text: string; bold: boolean }> = [];
      let currentLineWidth = 0;

      const addLine = () => {
        if (currentLine.length === 0) return;

        const totalWords = currentLine.reduce((sum, part) => sum + part.text.split(" ").length, 0);
        const isLastLine = false;

        let xPos = margin;
        currentLine.forEach((part, idx) => {
          doc.setFont("helvetica", part.bold ? "bold" : "normal");
          const words = part.text.split(" ");

          words.forEach((word, wordIdx) => {
            const wordWidth = doc.getTextWidth(word + " ");
            if (xPos + wordWidth > margin + maxWidth && xPos > margin) {
              currentY += 4;
              xPos = margin;
            }
            doc.text(word + (wordIdx < words.length - 1 ? " " : ""), xPos, currentY);
            xPos += wordWidth;
          });
        });

        currentY += 4;
        currentLine = [];
        currentLineWidth = 0;
      };

      parts.forEach((part) => {
        const words = part.text.split(" ");
        words.forEach((word) => {
          doc.setFont("helvetica", part.bold ? "bold" : "normal");
          const wordWidth = doc.getTextWidth(word + " ");

          if (currentLineWidth + wordWidth > maxWidth && currentLine.length > 0) {
            addLine();
          }

          currentLine.push({ text: word, bold: part.bold });
          currentLineWidth += wordWidth;
        });
      });

      if (currentLine.length > 0) addLine();

      return currentY;
    };

    // Header
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("SERVIÇO PÚBLICO FEDERAL MINISTÉRIO DA", centerX, y, { align: "center" });
    y += 4;
    doc.text("EDUCAÇÃO", centerX, y, { align: "center" });
    y += 4;
    doc.text("UNIVERSIDADE FEDERAL DE SANTA CATARINA SECRETARIA DE CULTURA, ARTE E", centerX, y, { align: "center" });
    y += 4;
    doc.text("ESPORTE Departamento Artístico Cultural", centerX, y, { align: "center" });
    y += 4;
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.text("Praça Santos Dumont - Rua Desembargador Vitor Lima,", centerX, y, { align: "center" });
    y += 3;
    doc.text("117 - Trindade CEP 88040-400 Florianópolis - SC -", centerX, y, { align: "center" });
    y += 3;
    doc.text("Brasil", centerX, y, { align: "center" });
    y += 12;

    // Title
    doc.setFontSize(11);
    doc.setFont("helvetica", "bold");
    doc.text("TERMO DE AUTORIZAÇÃO PARA OCUPAÇÃO DOS ESPAÇOS DO", centerX, y, { align: "center" });
    y += 4;
    doc.text("DEPARTAMENTO ARTÍSTICO CULTURAL", centerX, y, { align: "center" });
    y += 6;

    // Edital title
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text(adminSettings.editalTitle, centerX, y, { align: "center" });
    y += 8;

    // Proponent name
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text(`Proponente: ${form.nomeCompleto}`, margin, y);
    y += 8;

    // Section I
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("I - PREÂMBULO:", margin, y);
    y += 6;

    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text("1. Espaço:", margin, y);
    y += 4;
    const espaco = form.espacoTeatro ? "Teatro Carmen Fossari" : form.espacoIgreja ? "Igreja da UFSC" : "-";
    doc.text(espaco, margin + 5, y);
    y += 5;

    doc.text("2. Evento:", margin, y);
    y += 4;
    const eventLines = doc.splitTextToSize(form.nomeEvento || "-", contentW - 5);
    doc.text(eventLines, margin + 5, y);
    y += eventLines.length * 4 + 2;

    doc.text("3. Data e horário de realização do evento, conforme informado na inscrição:", margin, y);
    y += 5;
    const dateLines = doc.splitTextToSize(form.dataHorarioEvento || "-", contentW - 5);
    doc.text(dateLines, margin + 5, y);
    y += dateLines.length * 4 + 3;

    if (form.outrasInformacoes) {
      y = checkPageBreak(y, 15);
      doc.text("4. Outras informações:", margin, y);
      y += 5;
      const otherLines = doc.splitTextToSize(form.outrasInformacoes, contentW - 5);
      doc.text(otherLines, margin + 5, y);
      y += otherLines.length * 4 + 3;
    }

    // Section II - Completely continuous with bold data inline
    y = checkPageBreak(y, 25);
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("II - PARTES ENVOLVIDAS:", margin, y);
    y += 7;

    doc.setFontSize(9);

    // Build section II with parts for mixed formatting
    const section2Parts: Array<{ text: string; bold: boolean }> = [
      {
        text: "Termo de autorização de uso do espaço cultural acima especificado, que entre si celebram, de um lado, — — a UNIVERSIDADE FEDERAL DE SANTA CATARINA, com sede no Campus Universitário Florianópolis, s/n Trindade Florianópolis (SC) - CEP.: 88040-900, inscrita no CNPJ sob o nº 83.899.526/0001-82, doravante denominada simplesmente de AUTORIZADORA, neste ato representada por ",
        bold: false,
      },
      { text: adminSettings.responsavelNome || "Andréa Búrigo Ventura", bold: false },
      {
        text: ", Secretaria de Cultura Arte e Esporte - DAC SeCArtE e de outro lado ",
        bold: false,
      },
      { text: form.nomeCompleto || "[Nome do Proponente]", bold: true },
      { text: ", portador(a) do CPF/CNPJ sob o nº ", bold: false },
      { text: form.cpfCnpj || "[CPF/CNPJ]", bold: true },
      { text: ", RG nº ", bold: false },
      { text: form.rg || "[RG]", bold: true },
      { text: ", expedida pela SSP SC, residente à ", bold: false },
      { text: form.endereco || "[Endereço]", bold: true },
      { text: ", nº ", bold: false },
      { text: form.numero || "[Nº]", bold: true },
      { text: ", Bairro ", bold: false },
      { text: form.bairro || "[Bairro]", bold: true },
      { text: ", Telefone ", bold: false },
      { text: form.telefone || "[Telefone]", bold: true },
      { text: ", na cidade de ", bold: false },
      { text: form.cidade || "[Cidade]", bold: true },
      { text: ", doravante denominado(a) AUTORIZADO(A), mediante as seguintes cláusulas:", bold: false },
    ];

    // Render Section II with justified text
    const renderJustifiedMixedText = (parts: Array<{ text: string; bold: boolean }>, startY: number, maxWidth: number) => {
      let currentY = startY;
      doc.setFontSize(9);

      let currentLine: Array<{ text: string; bold: boolean }> = [];
      let currentLineWidth = 0;

      const addLine = () => {
        if (currentLine.length === 0) return;

        const totalWords = currentLine.reduce((sum, part) => sum + part.text.split(" ").length, 0);
        let xPos = margin;
        let totalWidth = 0;

        // Calculate total width of words
        currentLine.forEach((part) => {
          doc.setFont("helvetica", part.bold ? "bold" : "normal");
          const words = part.text.split(" ");
          words.forEach((word) => {
            totalWidth += doc.getTextWidth(word);
          });
        });

        // Check if this is the last line (approximate - if it's short)
        const isLastLine = totalWidth < maxWidth * 0.7;

        if (!isLastLine && totalWords > 1) {
          // Justified: distribute spaces
          const gaps = totalWords - 1;
          const spaceWidth = (maxWidth - totalWidth) / gaps;
          let wordCount = 0;

          currentLine.forEach((part) => {
            doc.setFont("helvetica", part.bold ? "bold" : "normal");
            const words = part.text.split(" ");

            words.forEach((word, wordIdx) => {
              doc.text(word, xPos, currentY);
              xPos += doc.getTextWidth(word);
              if (wordCount < totalWords - 1) {
                xPos += spaceWidth;
              }
              wordCount++;
            });
          });
        } else {
          // Left-aligned for last line
          currentLine.forEach((part) => {
            doc.setFont("helvetica", part.bold ? "bold" : "normal");
            const words = part.text.split(" ");
            words.forEach((word) => {
              doc.text(word, xPos, currentY);
              xPos += doc.getTextWidth(word + " ");
            });
          });
        }

        currentY += 4;
        currentLine = [];
        currentLineWidth = 0;
      };

      parts.forEach((part) => {
        const words = part.text.split(" ");
        words.forEach((word) => {
          doc.setFont("helvetica", part.bold ? "bold" : "normal");
          const wordWidth = doc.getTextWidth(word + " ");

          if (currentLineWidth + wordWidth > maxWidth && currentLine.length > 0) {
            addLine();
          }

          currentLine.push({ text: word, bold: part.bold });
          currentLineWidth += wordWidth;
        });
      });

      if (currentLine.length > 0) addLine();

      return currentY;
    };

    y = renderJustifiedMixedText(section2Parts, y, contentW - 10);
    y += 8; // Increased spacing before Section III

    // Section III
    y = checkPageBreak(y, 25);
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("III - CLÁUSULAS PACTUADAS ENTRE AS PARTES ENVOLVIDAS:", margin, y);
    y += 8; // Increased spacing after section title

    clausulas.forEach((clausula, index) => {
      // For clause 4, force a page break
      if (index === 3) {
        y = checkPageBreak(y, 300); // Force page break
      } else {
        y = checkPageBreak(y, 15);
      }
      // Add spacing before clause title (except first clause)
      if (index > 0) {
        y += 6;
      }
      doc.setFontSize(9);
      doc.setFont("helvetica", "bold");
      const clausulaLines = doc.splitTextToSize(clausula.titulo, contentW);
      doc.text(clausulaLines, margin, y);
      y += clausulaLines.length * 4 + 3;

      doc.setFont("helvetica", "normal");
      clausula.conteudo.forEach((para) => {
        y = checkPageBreak(y, 10);
        // Render paragraph with justified text
        const words = para.split(" ").filter(w => w);
        const lines: string[][] = [];
        let currentLine: string[] = [];
        let currentLineWidth = 0;

        words.forEach((word) => {
          const wordWidth = doc.getTextWidth(word + " ");
          if (currentLineWidth + wordWidth > contentW && currentLine.length > 0) {
            lines.push(currentLine);
            currentLine = [word];
            currentLineWidth = wordWidth;
          } else {
            currentLine.push(word);
            currentLineWidth += wordWidth;
          }
        });
        if (currentLine.length > 0) lines.push(currentLine);

        // Render justified lines
        lines.forEach((line, lineIdx) => {
          const isLastLine = lineIdx === lines.length - 1;
          let xPos = margin;

          if (!isLastLine && line.length > 1) {
            const totalWidth = line.reduce((sum, w) => sum + doc.getTextWidth(w), 0);
            const gaps = line.length - 1;
            const spaceWidth = (contentW - totalWidth) / gaps;

            line.forEach((word, wordIdx) => {
              doc.text(word, xPos, y);
              xPos += doc.getTextWidth(word) + spaceWidth;
            });
          } else {
            doc.text(line.join(" "), margin, y);
          }

          y += 4;
        });
      });
    });

    // Date section
    y = checkPageBreak(y, 30);
    y += 5;

    const today = new Date();
    const day = today.getDate();
    const monthNames = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
    const month = monthNames[today.getMonth()];
    const year = today.getFullYear();
    const dateStr = `Florianópolis (SC), ${day} de ${month} de ${year}`;

    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.text(dateStr, centerX, y, { align: "center" });
    y += 25;



    // Signature lines - aligned and professional with more space
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");

    const signLineY = y;
    const lineLength = 55;
    const leftX = margin + 5;
    const rightX = centerX + 8;

    // Draw signature lines
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.5);
    doc.line(leftX, signLineY, leftX + lineLength, signLineY);
    doc.line(rightX, signLineY, rightX + lineLength, signLineY);

    // Labels below lines
    y = signLineY + 8;
    doc.setFontSize(8);
    doc.setFont("helvetica", "bold");
    doc.text("AUTORIZADORA", leftX, y);
    doc.text("AUTORIZADO (A)", rightX, y);

    // CPF fields
    y += 6;
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    const cpfDisplay = adminSettings.cpfAutorizadora || "_________________";
    // Only show CPF line for AUTORIZADORA if it's filled
    if (adminSettings.cpfAutorizadora) {
      doc.text(`CPF - ${cpfDisplay}`, leftX, y);
    }
    doc.text(`CPF - ${form.cpfCnpj}`, rightX, y);

    doc.save(`Termo_DAC_2026_${form.nomeCompleto.replace(/\s+/g, "_") || "formulario"}.pdf`);
    toast.success("PDF gerado com sucesso!");
  }

  function limparFormulario() {
    setForm(initialForm);
    setErrors({});
    setOpenClausulas(clausulas.map(() => false));
    setClausulasAutorizadas(clausulas.map(() => false));
    toast.info("Formulário limpo.");
  }

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Header with Admin Icon */}
        <div className="flex items-center justify-between mb-8">
          <div className="text-center flex-1">
            <div className="flex items-center justify-center gap-3 mb-2">
              <FileText className="w-8 h-8 text-blue-600" />
              <h1 className="text-3xl font-bold text-gray-900">Termo de Autorização</h1>
            </div>
            <p className="text-gray-500 text-sm">DAC 2026 - Autorização de Uso dos Espaços</p>
          </div>
          <button
            onClick={() => setLocation("/admin")}
            className="ml-4 p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
            title="Configurações Administrativas"
          >
            <Settings className="w-6 h-6" />
          </button>
        </div>

        {/* Section I */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-4 overflow-hidden">
          <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
            <h2 className="text-base font-semibold text-gray-800">I - Preâmbulo</h2>
            <p className="text-xs text-gray-500 mt-0.5">Informações sobre o evento e o espaço</p>
          </div>
          <div className="px-6 py-5 space-y-5">
            {/* Field 1 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                1. Espaço físico objeto desta autorização <span className="text-red-500">*</span>
              </label>
              <div className="flex gap-4">
                <button
                  id="teatro"
                  role="checkbox"
                  aria-checked={form.espacoTeatro}
                  type="button"
                  onClick={() => handleChange("espacoTeatro", !form.espacoTeatro)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md border text-sm font-medium transition-colors ${
                    form.espacoTeatro
                      ? "bg-blue-600 text-white border-blue-600"
                      : "bg-white text-gray-700 border-gray-300 hover:border-blue-400"
                  }`}
                >
                  <span className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 ${form.espacoTeatro ? "bg-white border-white" : "border-gray-400"}`}>
                    {form.espacoTeatro && <svg className="w-3 h-3 text-blue-600" fill="none" viewBox="0 0 12 12"><path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                  </span>
                  Teatro Carmen Fossari
                </button>
                <button
                  id="igreja"
                  role="checkbox"
                  aria-checked={form.espacoIgreja}
                  type="button"
                  onClick={() => handleChange("espacoIgreja", !form.espacoIgreja)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md border text-sm font-medium transition-colors ${
                    form.espacoIgreja
                      ? "bg-blue-600 text-white border-blue-600"
                      : "bg-white text-gray-700 border-gray-300 hover:border-blue-400"
                  }`}
                >
                  <span className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 ${form.espacoIgreja ? "bg-white border-white" : "border-gray-400"}`}>
                    {form.espacoIgreja && <svg className="w-3 h-3 text-blue-600" fill="none" viewBox="0 0 12 12"><path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                  </span>
                  Igreja da UFSC
                </button>
              </div>
              {errors.espacoTeatro && <p className="text-red-500 text-xs mt-1">{errors.espacoTeatro}</p>}
            </div>

            {/* Field 2 */}
            <div>
              <label htmlFor="nomeEvento" className="block text-sm font-medium text-gray-700 mb-1">
                2. Evento a ser realizado no espaço físico objeto desta autorização <span className="text-red-500">*</span>
              </label>
              <textarea
                id="nomeEvento"
                value={form.nomeEvento}
                onChange={(e) => handleChange("nomeEvento", e.target.value)}
                placeholder="Ex: PALESTRA: ARQUITETURA E ENVELHECIMENTO..."
                rows={3}
                className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors resize-none ${
                  errors.nomeEvento ? "border-red-400 bg-red-50" : "border-gray-300"
                }`}
              />
              {errors.nomeEvento && <p className="text-red-500 text-xs mt-1">{errors.nomeEvento}</p>}
            </div>

            {/* Field 3 - Free text date/time */}
            <div>
              <label htmlFor="dataHorarioEvento" className="block text-sm font-medium text-gray-700 mb-1">
                3. Data e horário de realização do evento, conforme informado na inscrição, incluindo os horários de ensaio e montagem, caso tenham sido previstos. <span className="text-red-500">*</span>
              </label>
              <textarea
                id="dataHorarioEvento"
                value={form.dataHorarioEvento}
                onChange={(e) => handleChange("dataHorarioEvento", e.target.value)}
                placeholder="Ex: 15 de abril (quarta-feira) das 13:30 as 15:30"
                rows={2}
                className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors resize-none ${
                  errors.dataHorarioEvento ? "border-red-400 bg-red-50" : "border-gray-300"
                }`}
              />
              {errors.dataHorarioEvento && <p className="text-red-500 text-xs mt-1">{errors.dataHorarioEvento}</p>}
            </div>

            {/* Field 4 */}
            <div>
              <label htmlFor="outrasInformacoes" className="block text-sm font-medium text-gray-700 mb-1">
                4. Outras informações
              </label>
              <textarea
                id="outrasInformacoes"
                value={form.outrasInformacoes}
                onChange={(e) => handleChange("outrasInformacoes", e.target.value)}
                placeholder="Informações adicionais sobre o evento..."
                rows={3}
                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors resize-none"
              />
            </div>
          </div>
        </div>

        {/* Section II */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-4 overflow-hidden">
          <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
            <h2 className="text-base font-semibold text-gray-800">II - Partes Envolvidas</h2>
            <p className="text-xs text-gray-500 mt-0.5">Dados do Proponente (AUTORIZADO/A)</p>
          </div>
          <div className="px-6 py-5">
            <div className="grid grid-cols-2 gap-4">
              {/* Nome Completo */}
              <div>
                <label htmlFor="nomeCompleto" className="block text-xs font-medium text-gray-600 mb-1">
                  Nome Completo <span className="text-red-500">*</span>
                </label>
                <input
                  id="nomeCompleto"
                  type="text"
                  value={form.nomeCompleto}
                  onChange={(e) => handleChange("nomeCompleto", e.target.value)}
                  placeholder="Ex: João da Silva"
                  className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors ${
                    errors.nomeCompleto ? "border-red-400 bg-red-50" : "border-gray-300"
                  }`}
                />
                {errors.nomeCompleto && <p className="text-red-500 text-xs mt-1">{errors.nomeCompleto}</p>}
              </div>
              {/* CPF/CNPJ */}
              <div>
                <label htmlFor="cpfCnpj" className="block text-xs font-medium text-gray-600 mb-1">
                  CPF/CNPJ <span className="text-red-500">*</span>
                </label>
                <input
                  id="cpfCnpj"
                  type="text"
                  value={form.cpfCnpj}
                  onChange={(e) => handleChange("cpfCnpj", e.target.value)}
                  placeholder="Ex: 123.456.789-00"
                  className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors ${
                    errors.cpfCnpj ? "border-red-400 bg-red-50" : "border-gray-300"
                  }`}
                />
                {errors.cpfCnpj && <p className="text-red-500 text-xs mt-1">{errors.cpfCnpj}</p>}
              </div>

              {/* RG */}
              <div>
                <label htmlFor="rg" className="block text-xs font-medium text-gray-600 mb-1">
                  RG <span className="text-red-500">*</span>
                </label>
                <input
                  id="rg"
                  type="text"
                  value={form.rg}
                  onChange={(e) => handleChange("rg", e.target.value)}
                  placeholder="Ex: 2 662 359"
                  className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors ${
                    errors.rg ? "border-red-400 bg-red-50" : "border-gray-300"
                  }`}
                />
                {errors.rg && <p className="text-red-500 text-xs mt-1">{errors.rg}</p>}
              </div>

              {/* Telefone */}
              <div>
                <label htmlFor="telefone" className="block text-xs font-medium text-gray-600 mb-1">
                  Telefone <span className="text-red-500">*</span>
                </label>
                <input
                  id="telefone"
                  type="text"
                  value={form.telefone}
                  onChange={(e) => handleChange("telefone", e.target.value)}
                  placeholder="Ex: (48) 99105-6214"
                  className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors ${
                    errors.telefone ? "border-red-400 bg-red-50" : "border-gray-300"
                  }`}
                />
                {errors.telefone && <p className="text-red-500 text-xs mt-1">{errors.telefone}</p>}
              </div>

              {/* Endereço */}
              <div>
                <label htmlFor="endereco" className="block text-xs font-medium text-gray-600 mb-1">
                  Endereço <span className="text-red-500">*</span>
                </label>
                <input
                  id="endereco"
                  type="text"
                  value={form.endereco}
                  onChange={(e) => handleChange("endereco", e.target.value)}
                  placeholder="Ex: Rua Itapiranga"
                  className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors ${
                    errors.endereco ? "border-red-400 bg-red-50" : "border-gray-300"
                  }`}
                />
                {errors.endereco && <p className="text-red-500 text-xs mt-1">{errors.endereco}</p>}
              </div>

              {/* Nº */}
              <div>
                <label htmlFor="numero" className="block text-xs font-medium text-gray-600 mb-1">
                  Nº <span className="text-red-500">*</span>
                </label>
                <input
                  id="numero"
                  type="text"
                  value={form.numero}
                  onChange={(e) => handleChange("numero", e.target.value)}
                  placeholder="Ex: 280"
                  className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors ${
                    errors.numero ? "border-red-400 bg-red-50" : "border-gray-300"
                  }`}
                />
                {errors.numero && <p className="text-red-500 text-xs mt-1">{errors.numero}</p>}
              </div>

              {/* Apto */}
              <div>
                <label htmlFor="apartamento" className="block text-xs font-medium text-gray-600 mb-1">
                  Apto
                </label>
                <input
                  id="apartamento"
                  type="text"
                  value={form.apartamento}
                  onChange={(e) => handleChange("apartamento", e.target.value)}
                  placeholder="Ex: 903"
                  className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                />
              </div>

              {/* Bairro */}
              <div>
                <label htmlFor="bairro" className="block text-xs font-medium text-gray-600 mb-1">
                  Bairro <span className="text-red-500">*</span>
                </label>
                <input
                  id="bairro"
                  type="text"
                  value={form.bairro}
                  onChange={(e) => handleChange("bairro", e.target.value)}
                  placeholder="Ex: Itacorubi"
                  className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors ${
                    errors.bairro ? "border-red-400 bg-red-50" : "border-gray-300"
                  }`}
                />
                {errors.bairro && <p className="text-red-500 text-xs mt-1">{errors.bairro}</p>}
              </div>

              {/* Cidade */}
              <div>
                <label htmlFor="cidade" className="block text-xs font-medium text-gray-600 mb-1">
                  Cidade <span className="text-red-500">*</span>
                </label>
                <input
                  id="cidade"
                  type="text"
                  value={form.cidade}
                  onChange={(e) => handleChange("cidade", e.target.value)}
                  placeholder="Ex: Florianópolis"
                  className={`w-full rounded-md border px-3 py-2 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors ${
                    errors.cidade ? "border-red-400 bg-red-50" : "border-gray-300"
                  }`}
                />
                {errors.cidade && <p className="text-red-500 text-xs mt-1">{errors.cidade}</p>}
              </div>
            </div>
          </div>
        </div>

        {/* Section III - Clauses with cascade authorization */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-4 overflow-hidden">
          <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
            <h2 className="text-base font-semibold text-gray-800">III - Cláusulas Pactuadas</h2>
            <p className="text-xs text-gray-500 mt-0.5">Clique para expandir e ler cada cláusula</p>
          </div>
          <div className="divide-y divide-gray-100">
            {clausulas.map((clausula, index) => {
              const isEnabled = isClausulaEnabled(index);
              const isAuthorized = clausulasAutorizadas[index];
              return (
                <div key={index} className={isEnabled ? "" : "opacity-40 pointer-events-none"}>
                  <button
                    type="button"
                    onClick={() => isEnabled && toggleClausula(index)}
                    disabled={!isEnabled}
                    className={`w-full flex items-center justify-between px-6 py-4 text-left transition-colors ${
                      isEnabled ? "hover:bg-gray-50" : ""
                    }`}
                  >
                    <span className="text-sm font-medium text-gray-800">{clausula.titulo}</span>
                    {openClausulas[index] ? (
                      <ChevronUp className="w-4 h-4 text-gray-400 flex-shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
                    )}
                  </button>
                  {openClausulas[index] && isEnabled && (
                    <div className="px-6 pb-4 space-y-4">
                      <div className="space-y-2">
                        {clausula.conteudo.map((para, pIdx) => (
                          <p key={pIdx} className="text-sm text-gray-600 leading-relaxed">
                            {para}
                          </p>
                        ))}
                      </div>
                      <button
                        type="button"
                        onClick={() => toggleClausulaAutorizacao(index)}
                        className="flex items-start gap-3 w-full text-left mt-4 pt-4 border-t border-gray-200"
                      >
                        <span
                          className={`mt-0.5 w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                            isAuthorized ? "bg-green-600 border-green-600" : "bg-blue-50 border-blue-400"
                          }`}
                        >
                          {isAuthorized && (
                            <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 12 12">
                              <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                          )}
                        </span>
                        <div>
                          <span className="text-sm font-medium text-gray-800">
                            {isAuthorized ? "✓ Cláusula autorizada" : "Confirmo que li e aprovo este termo"}
                          </span>
                        </div>
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Acceptance */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6 px-6 py-5">
          <button
            id="aceitaTermos"
            role="checkbox"
            aria-checked={form.aceitaTermos}
            type="button"
            onClick={() => handleChange("aceitaTermos", !form.aceitaTermos)}
            className="flex items-start gap-3 w-full text-left"
          >
            <span
              className={`mt-0.5 w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                form.aceitaTermos ? "bg-blue-600 border-blue-600" : errors.aceitaTermos ? "border-red-400" : "border-gray-300"
              }`}
            >
              {form.aceitaTermos && (
                <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 12 12">
                  <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </span>
            <div>
              <span className="text-sm font-medium text-gray-800">
                Aceito os termos e condições acima descritos <span className="text-red-500">*</span>
              </span>
              <p className="text-xs text-gray-500 mt-0.5">
                Confirmo que li e concordo com todas as cláusulas e condições estabelecidas para o uso do espaço.
              </p>
            </div>
          </button>
          {errors.aceitaTermos && <p className="text-red-500 text-xs mt-2 ml-8">{errors.aceitaTermos}</p>}
        </div>

        {/* Buttons */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6 px-6 py-5">
          <div className="flex gap-3">
            <button
              type="button"
              onClick={gerarPDF}
              disabled={!allClausulasAutorizadas()}
              className={`flex-1 flex items-center justify-center gap-2 font-medium py-2.5 px-6 rounded-md transition-colors text-sm ${
                allClausulasAutorizadas()
                  ? "bg-blue-600 hover:bg-blue-700 text-white"
                  : "bg-gray-200 text-gray-400 cursor-not-allowed"
              }`}
            >
              <Download className="w-4 h-4" />
              Gerar PDF
            </button>
            <button
              type="button"
              onClick={limparFormulario}
              className="flex-1 flex items-center justify-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium py-2.5 px-6 rounded-md transition-colors text-sm"
            >
              <Trash2 className="w-4 h-4" />
              Limpar Formulário
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-gray-500 mb-4">* Campos obrigatórios</p>
      </div>
    </div>
  );
}

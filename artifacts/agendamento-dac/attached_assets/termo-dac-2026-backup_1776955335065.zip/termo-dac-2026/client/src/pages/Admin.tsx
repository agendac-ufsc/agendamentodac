import { useState, useEffect } from "react";
import { Lock, Save, X, Share2 } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

interface AdminSettings {
  editalTitle: string;
  responsavelNome: string;
  cpfAutorizadora: string;
}

const defaultSettings: AdminSettings = {
  editalTitle: "Este documento é parte integrante do Edital Mais Arte - N° 002/2026/DAC/SeCArtE",
  responsavelNome: "Andréa Búrigo Ventura",
  cpfAutorizadora: "",
};

export default function Admin() {
  const [, setLocation] = useLocation();
  const [password, setPassword] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [settings, setSettings] = useState<AdminSettings>(defaultSettings);
  const [hasChanges, setHasChanges] = useState(false);

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem("adminSettings");
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
    
    // Check if already authenticated in this session
    const isAuth = sessionStorage.getItem("adminAuthenticated");
    if (isAuth === "true") {
      setIsAuthenticated(true);
    }
  }, []);

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "admin.dac.ufsc") {
      setIsAuthenticated(true);
      sessionStorage.setItem("adminAuthenticated", "true");
      setPassword("");
      toast.success("Autenticado com sucesso!");
    } else {
      toast.error("Senha incorreta!");
      setPassword("");
    }
  };

  const handleSettingChange = (key: keyof AdminSettings, value: string) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    localStorage.setItem("adminSettings", JSON.stringify(settings));
    setHasChanges(false);
    toast.success("Configurações salvas com sucesso!");
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem("adminAuthenticated");
    setPassword("");
    setLocation("/");
    toast.info("Desconectado");
  };

  const generateShareableLink = () => {
    const baseUrl = window.location.origin;
    const params = new URLSearchParams();
    if (settings.editalTitle) params.append("edital", settings.editalTitle);
    if (settings.responsavelNome) params.append("responsavel", settings.responsavelNome);
    if (settings.cpfAutorizadora) params.append("cpf", settings.cpfAutorizadora);
    
    const shareableLink = `${baseUrl}?${params.toString()}`;
    
    // Copy to clipboard
    navigator.clipboard.writeText(shareableLink);
    toast.success("Link copiado para a área de transferência!");
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
          <div className="flex items-center justify-center mb-6">
            <Lock className="w-8 h-8 text-blue-600 mr-3" />
            <h1 className="text-2xl font-bold text-gray-800">Painel Administrativo</h1>
          </div>
          
          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Senha de Acesso
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Digite a senha"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                autoFocus
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition"
            >
              Entrar
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <button
              onClick={() => setLocation("/")}
              className="w-full text-gray-600 hover:text-gray-800 font-medium py-2"
            >
              ← Voltar ao Formulário
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6 flex items-center justify-between">
          <div className="flex items-center">
            <Lock className="w-6 h-6 text-blue-600 mr-3" />
            <h1 className="text-2xl font-bold text-gray-800">Configurações Administrativas</h1>
          </div>
          <button
            onClick={handleLogout}
            className="text-gray-500 hover:text-gray-700"
            title="Sair"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Settings Form */}
        <div className="bg-white rounded-lg shadow-md p-6 space-y-6">
          {/* Edital Title */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Título do Edital
            </label>
            <textarea
              value={settings.editalTitle}
              onChange={(e) => handleSettingChange("editalTitle", e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              rows={3}
              placeholder="Ex: Este documento é parte integrante do Edital Mais Arte - N° 002/2026/DAC/SeCArtE"
            />
            <p className="text-xs text-gray-500 mt-1">
              Este texto aparecerá no topo do PDF. Pode ser alterado conforme o ano ou edital.
            </p>
          </div>

          {/* Responsável Nome */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Nome da Responsável (Autorizadora)
            </label>
            <input
              type="text"
              value={settings.responsavelNome}
              onChange={(e) => handleSettingChange("responsavelNome", e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: Andréa Búrigo Ventura"
            />
            <p className="text-xs text-gray-500 mt-1">
              Este nome aparecerá na seção de assinaturas do PDF como Secretária de Cultura, Arte e Esporte.
            </p>
          </div>

          {/* CPF Autorizadora */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              CPF da Autorizadora (Opcional)
            </label>
            <input
              type="text"
              value={settings.cpfAutorizadora}
              onChange={(e) => handleSettingChange("cpfAutorizadora", e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: 123.456.789-00"
            />
            <p className="text-xs text-gray-500 mt-1">
              Este CPF aparecerá abaixo do nome da Autorizadora na seção de assinaturas. Deixe em branco para preencher manualmente.
            </p>
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4 border-t border-gray-200 flex-wrap">
            <button
              onClick={handleSave}
              disabled={!hasChanges}
              className={`flex items-center gap-2 px-6 py-2 rounded-lg font-semibold transition ${
                hasChanges
                  ? "bg-green-600 hover:bg-green-700 text-white cursor-pointer"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
            >
              <Save className="w-4 h-4" />
              Salvar Alterações
            </button>
            <button
              onClick={generateShareableLink}
              className="flex items-center gap-2 px-6 py-2 rounded-lg font-semibold bg-blue-600 hover:bg-blue-700 text-white transition"
              title="Gera um link com os parâmetros atuais e copia para a área de transferência"
            >
              <Share2 className="w-4 h-4" />
              Gerar Link
            </button>
            <button
              onClick={() => setLocation("/")}
              className="flex items-center gap-2 px-6 py-2 rounded-lg font-semibold bg-gray-200 hover:bg-gray-300 text-gray-700 transition"
            >
              Voltar ao Formulário
            </button>
          </div>
        </div>

        {/* Info Boxes */}
        <div className="mt-6 space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <strong>ℹ️ Informação:</strong> As alterações realizadas aqui serão aplicadas automaticamente a todos os PDFs gerados a partir de agora.
            </p>
          </div>
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <p className="text-sm text-purple-800">
              <strong>🔗 Link para Compartilhar:</strong> Clique em "Gerar Link" para criar um link personalizado com as configurações atuais. O link será copiado automaticamente para você compartilhar com os proponentes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
